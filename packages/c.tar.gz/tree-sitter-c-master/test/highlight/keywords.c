#include <stdlib.h>
// ^ keyword
//        ^ string

#include "something.h"
//        ^ string
