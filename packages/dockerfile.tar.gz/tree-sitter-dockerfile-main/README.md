tree-sitter-dockerfile
===========================

Dockerfile grammar for [tree-sitter][].

[tree-sitter]: https://github.com/tree-sitter/tree-sitter

An action shot of highlighting in neovim:
<img width="886" alt="Screen Shot 2021-06-29 at 08 35 19" src="https://user-images.githubusercontent.com/12631702/123816907-f1f4d780-d8b4-11eb-83d2-95fa3abacaf2.png">

